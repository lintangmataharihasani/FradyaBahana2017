<?php $__env->startSection('content'); ?>
<div id="index-banner" class="parallax-container">
   
  <h1 class="header center white-text text-shadow">Fradya Bahana Innovation</h1>    
</div>

<section id="errors">
  <div class="container">
      <h4>Halaman Yang Anda Maksud tidak ditemukan</h4>
      <a href="home">Back To Home</a>    
  </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>