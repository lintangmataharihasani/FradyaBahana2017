<?php $__env->startSection('content'); ?>
<div id="index-banner" class="parallax-container">
  <h1 class="header center white-text">Our Services</h1>
  <h5 class="header col s12 light"><?php echo e($header_tagline); ?></h5>
</div>

<div class="grey lighten-5">
  <div class="container">
    <div class="section">
      <h4 class="center">Service List</h4>
     <ul class="collapsible popout" data-collapsible="accordion">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li>

            <div class="collapsible-header"><img src="images/support.png" style="width: 40px;height: 40px; margin-top: 10px;" ><span class="pull-right"><?php echo e($service->nama); ?></span></div>               
            <div class="collapsible-body"><p><?php echo e($service->deskripsi); ?></p></div>
         </li>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
  </ul>
    </div>
    <?php echo e($services->links()); ?>

  </div>
<?php $__env->stopSection(); ?>
</div>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>