<?php $__env->startSection('content'); ?>

<section id="products-admin">
    <div class="container">
      <div style="padding: 60px;" class="card">
          <div class="row ">
          		<h3><?php echo e($product); ?></h3>
          		<h5><strong>Available In</strong></h5>
          		<p>Concentration :
          		<?php $__currentLoopData = $concentration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          			<?php echo e($con->concentration); ?><span>% ,</span>  
          		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          		</p>
				<p>State :
          		<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          			<?php echo e($state->state); ?><span>,</span>  
          		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          		</p>
          		<a class="waves-effect wave-light btn red" href="dashboard">Back To Dashboard</a>

          	</div>
       </div>   
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>