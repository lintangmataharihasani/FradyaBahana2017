<!doctype html>
<html>
<head>
    @include('includes.head')
</head>
<body class="wrapper">
    @include('includes.header')
    @yield('content')
    @include('includes.footer')
</body>
</html>