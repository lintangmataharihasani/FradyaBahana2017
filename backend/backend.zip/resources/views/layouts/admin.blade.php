<!doctype html>
<html>
<head>
    @include('includes.head-admin')
</head>
<body id="dashboard-body">
    @include('includes.header-admin')
    @yield('content')
    @include('includes.footer-admin')
</body>
</html>