<header>
  <nav class="light-blue darken-4 white-text" role="navigation">
  <div class="nav-wrapper container white-text">
    <a id="logo-container" href="#" class="brand-logo">
      Dashboard
    </a>
    <ul class="right hide-on-med-and-down">
      <li><a href="logout" class="white-text">Logout</a></li>
    </ul>

    <ul id="nav-mobile" class="side-nav">
      <li><a href="logout" class="white-text">Logout</a></li>
    </ul>
    <a href="#" data-activates="nav-mobile" class="button-collapse white-text"><i class="material-icons">menu</i></a>
  </div>
</nav>
</header>