@extends('layouts.default')
@section('content')
<h1>{{$kategori}}</h1>

@stop